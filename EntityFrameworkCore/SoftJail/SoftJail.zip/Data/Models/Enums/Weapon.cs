﻿namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife = 0,
        FlashPulse = 1,
        ChainRifle = 2,
        Pistol = 3,
        Sniper = 4
    }
}
